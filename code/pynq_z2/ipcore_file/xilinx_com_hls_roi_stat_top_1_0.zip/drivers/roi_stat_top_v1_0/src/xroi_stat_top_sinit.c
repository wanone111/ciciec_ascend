// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xroi_stat_top.h"

extern XRoi_stat_top_Config XRoi_stat_top_ConfigTable[];

#ifdef SDT
XRoi_stat_top_Config *XRoi_stat_top_LookupConfig(UINTPTR BaseAddress) {
	XRoi_stat_top_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XRoi_stat_top_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XRoi_stat_top_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XRoi_stat_top_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XRoi_stat_top_Initialize(XRoi_stat_top *InstancePtr, UINTPTR BaseAddress) {
	XRoi_stat_top_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XRoi_stat_top_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XRoi_stat_top_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XRoi_stat_top_Config *XRoi_stat_top_LookupConfig(u16 DeviceId) {
	XRoi_stat_top_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XROI_STAT_TOP_NUM_INSTANCES; Index++) {
		if (XRoi_stat_top_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XRoi_stat_top_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XRoi_stat_top_Initialize(XRoi_stat_top *InstancePtr, u16 DeviceId) {
	XRoi_stat_top_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XRoi_stat_top_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XRoi_stat_top_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

