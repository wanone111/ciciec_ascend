// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of img
//        bit 31~0 - img[31:0] (Read/Write)
// 0x14 : Data signal of img
//        bit 31~0 - img[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of rows
//        bit 15~0 - rows[15:0] (Read/Write)
//        others   - reserved
// 0x20 : reserved
// 0x24 : Data signal of cols
//        bit 15~0 - cols[15:0] (Read/Write)
//        others   - reserved
// 0x28 : reserved
// 0x2c : Data signal of stride_bytes
//        bit 15~0 - stride_bytes[15:0] (Read/Write)
//        others   - reserved
// 0x30 : reserved
// 0x34 : Data signal of roi_x
//        bit 15~0 - roi_x[15:0] (Read/Write)
//        others   - reserved
// 0x38 : reserved
// 0x3c : Data signal of roi_y
//        bit 15~0 - roi_y[15:0] (Read/Write)
//        others   - reserved
// 0x40 : reserved
// 0x44 : Data signal of roi_w
//        bit 15~0 - roi_w[15:0] (Read/Write)
//        others   - reserved
// 0x48 : reserved
// 0x4c : Data signal of roi_h
//        bit 15~0 - roi_h[15:0] (Read/Write)
//        others   - reserved
// 0x50 : reserved
// 0x54 : Data signal of brightness_mean
//        bit 31~0 - brightness_mean[31:0] (Read)
// 0x58 : Control signal of brightness_mean
//        bit 0  - brightness_mean_ap_vld (Read/COR)
//        others - reserved
// 0x64 : Data signal of motion_score
//        bit 31~0 - motion_score[31:0] (Read)
// 0x68 : Control signal of motion_score
//        bit 0  - motion_score_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XROI_STAT_TOP_CONTROL_ADDR_AP_CTRL              0x00
#define XROI_STAT_TOP_CONTROL_ADDR_GIE                  0x04
#define XROI_STAT_TOP_CONTROL_ADDR_IER                  0x08
#define XROI_STAT_TOP_CONTROL_ADDR_ISR                  0x0c
#define XROI_STAT_TOP_CONTROL_ADDR_IMG_DATA             0x10
#define XROI_STAT_TOP_CONTROL_BITS_IMG_DATA             64
#define XROI_STAT_TOP_CONTROL_ADDR_ROWS_DATA            0x1c
#define XROI_STAT_TOP_CONTROL_BITS_ROWS_DATA            16
#define XROI_STAT_TOP_CONTROL_ADDR_COLS_DATA            0x24
#define XROI_STAT_TOP_CONTROL_BITS_COLS_DATA            16
#define XROI_STAT_TOP_CONTROL_ADDR_STRIDE_BYTES_DATA    0x2c
#define XROI_STAT_TOP_CONTROL_BITS_STRIDE_BYTES_DATA    16
#define XROI_STAT_TOP_CONTROL_ADDR_ROI_X_DATA           0x34
#define XROI_STAT_TOP_CONTROL_BITS_ROI_X_DATA           16
#define XROI_STAT_TOP_CONTROL_ADDR_ROI_Y_DATA           0x3c
#define XROI_STAT_TOP_CONTROL_BITS_ROI_Y_DATA           16
#define XROI_STAT_TOP_CONTROL_ADDR_ROI_W_DATA           0x44
#define XROI_STAT_TOP_CONTROL_BITS_ROI_W_DATA           16
#define XROI_STAT_TOP_CONTROL_ADDR_ROI_H_DATA           0x4c
#define XROI_STAT_TOP_CONTROL_BITS_ROI_H_DATA           16
#define XROI_STAT_TOP_CONTROL_ADDR_BRIGHTNESS_MEAN_DATA 0x54
#define XROI_STAT_TOP_CONTROL_BITS_BRIGHTNESS_MEAN_DATA 32
#define XROI_STAT_TOP_CONTROL_ADDR_BRIGHTNESS_MEAN_CTRL 0x58
#define XROI_STAT_TOP_CONTROL_ADDR_MOTION_SCORE_DATA    0x64
#define XROI_STAT_TOP_CONTROL_BITS_MOTION_SCORE_DATA    32
#define XROI_STAT_TOP_CONTROL_ADDR_MOTION_SCORE_CTRL    0x68

