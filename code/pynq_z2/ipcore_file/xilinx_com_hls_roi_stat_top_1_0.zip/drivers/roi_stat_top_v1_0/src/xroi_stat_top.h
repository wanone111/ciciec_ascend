// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XROI_STAT_TOP_H
#define XROI_STAT_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xroi_stat_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XRoi_stat_top_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XRoi_stat_top;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XRoi_stat_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XRoi_stat_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XRoi_stat_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XRoi_stat_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XRoi_stat_top_Initialize(XRoi_stat_top *InstancePtr, UINTPTR BaseAddress);
XRoi_stat_top_Config* XRoi_stat_top_LookupConfig(UINTPTR BaseAddress);
#else
int XRoi_stat_top_Initialize(XRoi_stat_top *InstancePtr, u16 DeviceId);
XRoi_stat_top_Config* XRoi_stat_top_LookupConfig(u16 DeviceId);
#endif
int XRoi_stat_top_CfgInitialize(XRoi_stat_top *InstancePtr, XRoi_stat_top_Config *ConfigPtr);
#else
int XRoi_stat_top_Initialize(XRoi_stat_top *InstancePtr, const char* InstanceName);
int XRoi_stat_top_Release(XRoi_stat_top *InstancePtr);
#endif

void XRoi_stat_top_Start(XRoi_stat_top *InstancePtr);
u32 XRoi_stat_top_IsDone(XRoi_stat_top *InstancePtr);
u32 XRoi_stat_top_IsIdle(XRoi_stat_top *InstancePtr);
u32 XRoi_stat_top_IsReady(XRoi_stat_top *InstancePtr);
void XRoi_stat_top_EnableAutoRestart(XRoi_stat_top *InstancePtr);
void XRoi_stat_top_DisableAutoRestart(XRoi_stat_top *InstancePtr);

void XRoi_stat_top_Set_img(XRoi_stat_top *InstancePtr, u64 Data);
u64 XRoi_stat_top_Get_img(XRoi_stat_top *InstancePtr);
void XRoi_stat_top_Set_rows(XRoi_stat_top *InstancePtr, u32 Data);
u32 XRoi_stat_top_Get_rows(XRoi_stat_top *InstancePtr);
void XRoi_stat_top_Set_cols(XRoi_stat_top *InstancePtr, u32 Data);
u32 XRoi_stat_top_Get_cols(XRoi_stat_top *InstancePtr);
void XRoi_stat_top_Set_stride_bytes(XRoi_stat_top *InstancePtr, u32 Data);
u32 XRoi_stat_top_Get_stride_bytes(XRoi_stat_top *InstancePtr);
void XRoi_stat_top_Set_roi_x(XRoi_stat_top *InstancePtr, u32 Data);
u32 XRoi_stat_top_Get_roi_x(XRoi_stat_top *InstancePtr);
void XRoi_stat_top_Set_roi_y(XRoi_stat_top *InstancePtr, u32 Data);
u32 XRoi_stat_top_Get_roi_y(XRoi_stat_top *InstancePtr);
void XRoi_stat_top_Set_roi_w(XRoi_stat_top *InstancePtr, u32 Data);
u32 XRoi_stat_top_Get_roi_w(XRoi_stat_top *InstancePtr);
void XRoi_stat_top_Set_roi_h(XRoi_stat_top *InstancePtr, u32 Data);
u32 XRoi_stat_top_Get_roi_h(XRoi_stat_top *InstancePtr);
u32 XRoi_stat_top_Get_brightness_mean(XRoi_stat_top *InstancePtr);
u32 XRoi_stat_top_Get_brightness_mean_vld(XRoi_stat_top *InstancePtr);
u32 XRoi_stat_top_Get_motion_score(XRoi_stat_top *InstancePtr);
u32 XRoi_stat_top_Get_motion_score_vld(XRoi_stat_top *InstancePtr);

void XRoi_stat_top_InterruptGlobalEnable(XRoi_stat_top *InstancePtr);
void XRoi_stat_top_InterruptGlobalDisable(XRoi_stat_top *InstancePtr);
void XRoi_stat_top_InterruptEnable(XRoi_stat_top *InstancePtr, u32 Mask);
void XRoi_stat_top_InterruptDisable(XRoi_stat_top *InstancePtr, u32 Mask);
void XRoi_stat_top_InterruptClear(XRoi_stat_top *InstancePtr, u32 Mask);
u32 XRoi_stat_top_InterruptGetEnabled(XRoi_stat_top *InstancePtr);
u32 XRoi_stat_top_InterruptGetStatus(XRoi_stat_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
