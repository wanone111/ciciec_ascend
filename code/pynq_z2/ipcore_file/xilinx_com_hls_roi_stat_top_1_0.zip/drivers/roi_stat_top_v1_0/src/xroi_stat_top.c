// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xroi_stat_top.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XRoi_stat_top_CfgInitialize(XRoi_stat_top *InstancePtr, XRoi_stat_top_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XRoi_stat_top_Start(XRoi_stat_top *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRoi_stat_top_ReadReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_AP_CTRL) & 0x80;
    XRoi_stat_top_WriteReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XRoi_stat_top_IsDone(XRoi_stat_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRoi_stat_top_ReadReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XRoi_stat_top_IsIdle(XRoi_stat_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRoi_stat_top_ReadReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XRoi_stat_top_IsReady(XRoi_stat_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRoi_stat_top_ReadReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XRoi_stat_top_EnableAutoRestart(XRoi_stat_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRoi_stat_top_WriteReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XRoi_stat_top_DisableAutoRestart(XRoi_stat_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRoi_stat_top_WriteReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_AP_CTRL, 0);
}

void XRoi_stat_top_Set_img(XRoi_stat_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRoi_stat_top_WriteReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_IMG_DATA, (u32)(Data));
    XRoi_stat_top_WriteReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_IMG_DATA + 4, (u32)(Data >> 32));
}

u64 XRoi_stat_top_Get_img(XRoi_stat_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRoi_stat_top_ReadReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_IMG_DATA);
    Data += (u64)XRoi_stat_top_ReadReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_IMG_DATA + 4) << 32;
    return Data;
}

void XRoi_stat_top_Set_rows(XRoi_stat_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRoi_stat_top_WriteReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_ROWS_DATA, Data);
}

u32 XRoi_stat_top_Get_rows(XRoi_stat_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRoi_stat_top_ReadReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_ROWS_DATA);
    return Data;
}

void XRoi_stat_top_Set_cols(XRoi_stat_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRoi_stat_top_WriteReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_COLS_DATA, Data);
}

u32 XRoi_stat_top_Get_cols(XRoi_stat_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRoi_stat_top_ReadReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_COLS_DATA);
    return Data;
}

void XRoi_stat_top_Set_stride_bytes(XRoi_stat_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRoi_stat_top_WriteReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_STRIDE_BYTES_DATA, Data);
}

u32 XRoi_stat_top_Get_stride_bytes(XRoi_stat_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRoi_stat_top_ReadReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_STRIDE_BYTES_DATA);
    return Data;
}

void XRoi_stat_top_Set_roi_x(XRoi_stat_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRoi_stat_top_WriteReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_ROI_X_DATA, Data);
}

u32 XRoi_stat_top_Get_roi_x(XRoi_stat_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRoi_stat_top_ReadReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_ROI_X_DATA);
    return Data;
}

void XRoi_stat_top_Set_roi_y(XRoi_stat_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRoi_stat_top_WriteReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_ROI_Y_DATA, Data);
}

u32 XRoi_stat_top_Get_roi_y(XRoi_stat_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRoi_stat_top_ReadReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_ROI_Y_DATA);
    return Data;
}

void XRoi_stat_top_Set_roi_w(XRoi_stat_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRoi_stat_top_WriteReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_ROI_W_DATA, Data);
}

u32 XRoi_stat_top_Get_roi_w(XRoi_stat_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRoi_stat_top_ReadReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_ROI_W_DATA);
    return Data;
}

void XRoi_stat_top_Set_roi_h(XRoi_stat_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRoi_stat_top_WriteReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_ROI_H_DATA, Data);
}

u32 XRoi_stat_top_Get_roi_h(XRoi_stat_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRoi_stat_top_ReadReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_ROI_H_DATA);
    return Data;
}

u32 XRoi_stat_top_Get_brightness_mean(XRoi_stat_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRoi_stat_top_ReadReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_BRIGHTNESS_MEAN_DATA);
    return Data;
}

u32 XRoi_stat_top_Get_brightness_mean_vld(XRoi_stat_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRoi_stat_top_ReadReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_BRIGHTNESS_MEAN_CTRL);
    return Data & 0x1;
}

u32 XRoi_stat_top_Get_motion_score(XRoi_stat_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRoi_stat_top_ReadReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_MOTION_SCORE_DATA);
    return Data;
}

u32 XRoi_stat_top_Get_motion_score_vld(XRoi_stat_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRoi_stat_top_ReadReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_MOTION_SCORE_CTRL);
    return Data & 0x1;
}

void XRoi_stat_top_InterruptGlobalEnable(XRoi_stat_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRoi_stat_top_WriteReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_GIE, 1);
}

void XRoi_stat_top_InterruptGlobalDisable(XRoi_stat_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRoi_stat_top_WriteReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_GIE, 0);
}

void XRoi_stat_top_InterruptEnable(XRoi_stat_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XRoi_stat_top_ReadReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_IER);
    XRoi_stat_top_WriteReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_IER, Register | Mask);
}

void XRoi_stat_top_InterruptDisable(XRoi_stat_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XRoi_stat_top_ReadReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_IER);
    XRoi_stat_top_WriteReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_IER, Register & (~Mask));
}

void XRoi_stat_top_InterruptClear(XRoi_stat_top *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRoi_stat_top_WriteReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_ISR, Mask);
}

u32 XRoi_stat_top_InterruptGetEnabled(XRoi_stat_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XRoi_stat_top_ReadReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_IER);
}

u32 XRoi_stat_top_InterruptGetStatus(XRoi_stat_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XRoi_stat_top_ReadReg(InstancePtr->Control_BaseAddress, XROI_STAT_TOP_CONTROL_ADDR_ISR);
}

