# ROI/YUV420-style HDMI AXIS HLS IP

## What this version does
- AXI4-Stream RGB888 input
- Internal RGB -> YUV conversion
- ROI statistics on Y plane
- 2x2 block chroma averaging inside ROI to obtain YUV420-style U/V means
- AXI4-Stream RGB888 output for compatibility with the common `v_vid_in_axi4s -> HLS IP -> v_axi4s_vid_out -> rgb2dvi` PYNQ-Z2 HDMI template

## Important limitation
This project **does not output true YUV420 over HDMI**. It keeps HDMI output as RGB888 because the common PYNQ-Z2 `rgb2dvi` output path expects 24-bit RGB.

What you get here is:
- true Y-plane processing for ROI and motion
- YUV420-style chroma subsampling statistics inside the HLS IP
- HDMI-compatible RGB output, with optional grayscale display modes

## Registers
- rows, cols
- roi_x, roi_y, roi_w, roi_h
- overlay_en
- out_mode
  - 0: RGB passthrough
  - 1: grayscale(Y) whole frame
  - 2: grayscale(Y) only in ROI, RGB elsewhere
- clear_history
- outputs: y_mean, motion_score, u_mean_420, v_mean_420
