#ifndef PYNQ_TOP_H_
#define PYNQ_TOP_H_

#include <ap_axi_sdata.h>
#include <ap_int.h>
#include <hls_stream.h>

#include "roi.h"
#include "video_params.h"

typedef ap_axiu<24, 1, 1, 1> axi_pixel_t;

void roi_stat_top(
    hls::stream<axi_pixel_t>& src,
    hls::stream<axi_pixel_t>& dst,
    ap_uint<16> rows,
    ap_uint<16> cols,
    ap_uint<16> roi_x,
    ap_uint<16> roi_y,
    ap_uint<16> roi_w,
    ap_uint<16> roi_h,
    ap_uint<8> overlay_en,
    ap_uint<8> out_mode,
    ap_uint<8> clear_history,
    ap_uint<32>& y_mean,
    ap_uint<32>& motion_score,
    ap_uint<32>& u_mean_420,
    ap_uint<32>& v_mean_420);

#endif  // PYNQ_TOP_H_
