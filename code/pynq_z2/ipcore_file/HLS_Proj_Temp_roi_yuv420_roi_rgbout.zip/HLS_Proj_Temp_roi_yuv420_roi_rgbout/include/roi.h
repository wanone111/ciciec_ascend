#ifndef PYNQ_ROI_H_
#define PYNQ_ROI_H_

#include <ap_int.h>
#include <stdbool.h>

#include "video_params.h"

struct RoiWindow {
    ap_uint<16> x0;
    ap_uint<16> y0;
    ap_uint<16> x1;
    ap_uint<16> y1;
    ap_uint<16> w;
    ap_uint<16> h;
};

struct YuvPixel {
    ap_uint<8> y;
    ap_uint<8> u;
    ap_uint<8> v;
};

RoiWindow pack_roi_window(ap_uint<16> rows,
                          ap_uint<16> cols,
                          ap_uint<16> roi_x,
                          ap_uint<16> roi_y,
                          ap_uint<16> roi_w,
                          ap_uint<16> roi_h);

bool roi_contains(const RoiWindow& roi, ap_uint<16> row, ap_uint<16> col);
bool roi_on_border(const RoiWindow& roi, ap_uint<16> row, ap_uint<16> col);
ap_uint<8> absdiff_u8(ap_uint<8> a, ap_uint<8> b);
YuvPixel rgb_to_yuv_bt601(ap_uint<8> r, ap_uint<8> g, ap_uint<8> b);
ap_uint<8> clip_u8_from_int(int v);

#endif  // PYNQ_ROI_H_
