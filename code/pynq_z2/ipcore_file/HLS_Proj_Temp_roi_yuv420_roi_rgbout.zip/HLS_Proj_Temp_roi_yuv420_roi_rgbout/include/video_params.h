#ifndef PYNQ_VIDEO_PARAMS_H_
#define PYNQ_VIDEO_PARAMS_H_

#include <ap_int.h>

static const int MAX_WIDTH = 1280;
static const int MAX_HEIGHT = 720;

// 上一帧 ROI 的亮度(Y)缓存放在片上 BRAM。
static const int MAX_ROI_WIDTH = 320;
static const int MAX_ROI_HEIGHT = 240;

struct VideoControl {
    ap_uint<16> rows;
    ap_uint<16> cols;

    ap_uint<16> roi_x;
    ap_uint<16> roi_y;
    ap_uint<16> roi_w;
    ap_uint<16> roi_h;

    ap_uint<8> overlay_en;
    // 0: RGB直通
    // 1: 全画面输出Y(灰度)
    // 2: 仅ROI区域输出Y(灰度)，其余保持RGB
    ap_uint<8> out_mode;
    ap_uint<8> clear_history;
};

#endif  // PYNQ_VIDEO_PARAMS_H_
