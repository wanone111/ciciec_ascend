#include "top.h"

void roi_stat_top(
    hls::stream<axi_pixel_t>& src,
    hls::stream<axi_pixel_t>& dst,
    ap_uint<16> rows,
    ap_uint<16> cols,
    ap_uint<16> roi_x,
    ap_uint<16> roi_y,
    ap_uint<16> roi_w,
    ap_uint<16> roi_h,
    ap_uint<8> overlay_en,
    ap_uint<8> out_mode,
    ap_uint<8> clear_history,
    ap_uint<32>& y_mean,
    ap_uint<32>& motion_score,
    ap_uint<32>& u_mean_420,
    ap_uint<32>& v_mean_420) {
#pragma HLS INTERFACE axis port=src
#pragma HLS INTERFACE axis port=dst
#pragma HLS INTERFACE s_axilite port=rows bundle=control
#pragma HLS INTERFACE s_axilite port=cols bundle=control
#pragma HLS INTERFACE s_axilite port=roi_x bundle=control
#pragma HLS INTERFACE s_axilite port=roi_y bundle=control
#pragma HLS INTERFACE s_axilite port=roi_w bundle=control
#pragma HLS INTERFACE s_axilite port=roi_h bundle=control
#pragma HLS INTERFACE s_axilite port=overlay_en bundle=control
#pragma HLS INTERFACE s_axilite port=out_mode bundle=control
#pragma HLS INTERFACE s_axilite port=clear_history bundle=control
#pragma HLS INTERFACE s_axilite port=y_mean bundle=control
#pragma HLS INTERFACE s_axilite port=motion_score bundle=control
#pragma HLS INTERFACE s_axilite port=u_mean_420 bundle=control
#pragma HLS INTERFACE s_axilite port=v_mean_420 bundle=control
#pragma HLS INTERFACE s_axilite port=return bundle=control

    static ap_uint<8> prev_y[MAX_ROI_HEIGHT][MAX_ROI_WIDTH];
#pragma HLS BIND_STORAGE variable=prev_y type=ram_2p impl=bram
#pragma HLS ARRAY_PARTITION variable=prev_y dim=2 cyclic factor=4

    static ap_uint<1> history_valid = 0;
    static ap_uint<16> last_roi_x = 0;
    static ap_uint<16> last_roi_y = 0;
    static ap_uint<16> last_roi_w = 0;
    static ap_uint<16> last_roi_h = 0;

    const ap_uint<16> proc_rows = rows;
    const ap_uint<16> proc_cols = cols;
    const RoiWindow roi = pack_roi_window(proc_rows, proc_cols, roi_x, roi_y, roi_w, roi_h);

    const bool roi_changed = (roi_x != last_roi_x) || (roi_y != last_roi_y) ||
                             (roi_w != last_roi_w) || (roi_h != last_roi_h);
    const bool bypass_motion = (clear_history != 0) || roi_changed || (history_valid == 0);

    ap_uint<32> sum_y = 0;
    ap_uint<32> sum_diff = 0;
    ap_uint<32> roi_count = 0;

    ap_uint<32> sum_u_420 = 0;
    ap_uint<32> sum_v_420 = 0;
    ap_uint<32> uv_block_count = 0;

    ap_uint<10> blk_u_sum = 0;
    ap_uint<10> blk_v_sum = 0;
    ap_uint<2> blk_pix_count = 0;
    bool blk_active = false;
    ap_uint<16> blk_base_x = 0;
    ap_uint<16> blk_base_y = 0;

row_loop:
    for (ap_uint<16> r = 0; r < proc_rows; ++r) {
    col_loop:
        for (ap_uint<16> c = 0; c < proc_cols; ++c) {
#pragma HLS PIPELINE II=1
            axi_pixel_t in_pix = src.read();
            axi_pixel_t out_pix = in_pix;

            const ap_uint<8> b = in_pix.data.range(7, 0);
            const ap_uint<8> g = in_pix.data.range(15, 8);
            const ap_uint<8> rr = in_pix.data.range(23, 16);

            const bool in_roi = roi_contains(roi, r, c);
            const bool on_border = roi_on_border(roi, r, c);
            const YuvPixel yuv = rgb_to_yuv_bt601(rr, g, b);

            ap_uint<8> out_r = rr;
            ap_uint<8> out_g = g;
            ap_uint<8> out_b = b;

            if (in_roi) {
                const ap_uint<16> ly = r - roi.y0;
                const ap_uint<16> lx = c - roi.x0;

                sum_y += yuv.y;
                ++roi_count;

                if (!bypass_motion && ly < MAX_ROI_HEIGHT && lx < MAX_ROI_WIDTH) {
                    sum_diff += absdiff_u8(yuv.y, prev_y[ly][lx]);
                }
                if (ly < MAX_ROI_HEIGHT && lx < MAX_ROI_WIDTH) {
                    prev_y[ly][lx] = yuv.y;
                }

                // 在 ROI 内按 2x2 block 累计 U/V，得到 YUV420 的色度均值。
                const ap_uint<16> cur_blk_x = lx & 0xFFFE;
                const ap_uint<16> cur_blk_y = ly & 0xFFFE;
                const bool same_block = blk_active && (cur_blk_x == blk_base_x) && (cur_blk_y == blk_base_y);

                if (!same_block) {
                    if (blk_active && blk_pix_count != 0) {
                        sum_u_420 += (blk_u_sum / blk_pix_count);
                        sum_v_420 += (blk_v_sum / blk_pix_count);
                        ++uv_block_count;
                    }
                    blk_active = true;
                    blk_base_x = cur_blk_x;
                    blk_base_y = cur_blk_y;
                    blk_u_sum = 0;
                    blk_v_sum = 0;
                    blk_pix_count = 0;
                }

                blk_u_sum += yuv.u;
                blk_v_sum += yuv.v;
                ++blk_pix_count;
            }

            if (out_mode == 1 || (out_mode == 2 && in_roi)) {
                out_r = yuv.y;
                out_g = yuv.y;
                out_b = yuv.y;
            }

            if (overlay_en && on_border) {
                out_r = 255;
                out_g = 0;
                out_b = 0;
            }

            out_pix.data.range(7, 0) = out_b;
            out_pix.data.range(15, 8) = out_g;
            out_pix.data.range(23, 16) = out_r;
            dst.write(out_pix);
        }
    }

    if (blk_active && blk_pix_count != 0) {
        sum_u_420 += (blk_u_sum / blk_pix_count);
        sum_v_420 += (blk_v_sum / blk_pix_count);
        ++uv_block_count;
    }

    y_mean = (roi_count != 0) ? (sum_y / roi_count) : 0;
    motion_score = (roi_count != 0) ? (sum_diff / roi_count) : 0;
    u_mean_420 = (uv_block_count != 0) ? (sum_u_420 / uv_block_count) : 0;
    v_mean_420 = (uv_block_count != 0) ? (sum_v_420 / uv_block_count) : 0;

    history_valid = 1;
    last_roi_x = roi_x;
    last_roi_y = roi_y;
    last_roi_w = roi_w;
    last_roi_h = roi_h;
}
