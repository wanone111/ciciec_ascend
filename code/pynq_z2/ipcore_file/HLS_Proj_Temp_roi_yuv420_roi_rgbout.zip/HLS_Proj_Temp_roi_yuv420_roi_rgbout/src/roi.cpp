#include "roi.h"

static inline ap_uint<16> clamp_u16(ap_uint<16> value, ap_uint<16> lo, ap_uint<16> hi) {
#pragma HLS INLINE
    if (value < lo) return lo;
    if (value > hi) return hi;
    return value;
}

RoiWindow pack_roi_window(ap_uint<16> rows,
                          ap_uint<16> cols,
                          ap_uint<16> roi_x,
                          ap_uint<16> roi_y,
                          ap_uint<16> roi_w,
                          ap_uint<16> roi_h) {
    RoiWindow roi;

    ap_uint<16> safe_rows = clamp_u16(rows, 1, MAX_HEIGHT);
    ap_uint<16> safe_cols = clamp_u16(cols, 1, MAX_WIDTH);

    roi.x0 = clamp_u16(roi_x, 0, (ap_uint<16>)(safe_cols - 1));
    roi.y0 = clamp_u16(roi_y, 0, (ap_uint<16>)(safe_rows - 1));

    ap_uint<16> w_req = (roi_w == 0) ? (ap_uint<16>)MAX_ROI_WIDTH : roi_w;
    ap_uint<16> h_req = (roi_h == 0) ? (ap_uint<16>)MAX_ROI_HEIGHT : roi_h;

    ap_uint<16> w_clip = (w_req > MAX_ROI_WIDTH) ? (ap_uint<16>)MAX_ROI_WIDTH : w_req;
    ap_uint<16> h_clip = (h_req > MAX_ROI_HEIGHT) ? (ap_uint<16>)MAX_ROI_HEIGHT : h_req;

    ap_uint<16> x1 = roi.x0 + w_clip;
    ap_uint<16> y1 = roi.y0 + h_clip;

    if (x1 > safe_cols) x1 = safe_cols;
    if (y1 > safe_rows) y1 = safe_rows;

    roi.x1 = x1;
    roi.y1 = y1;
    roi.w = roi.x1 - roi.x0;
    roi.h = roi.y1 - roi.y0;

    return roi;
}

bool roi_contains(const RoiWindow& roi, ap_uint<16> row, ap_uint<16> col) {
#pragma HLS INLINE
    return (row >= roi.y0) && (row < roi.y1) && (col >= roi.x0) && (col < roi.x1);
}

bool roi_on_border(const RoiWindow& roi, ap_uint<16> row, ap_uint<16> col) {
#pragma HLS INLINE
    if (!roi_contains(roi, row, col)) return false;
    return (row == roi.y0) || (row == (ap_uint<16>)(roi.y1 - 1)) ||
           (col == roi.x0) || (col == (ap_uint<16>)(roi.x1 - 1));
}

ap_uint<8> absdiff_u8(ap_uint<8> a, ap_uint<8> b) {
#pragma HLS INLINE
    return (a > b) ? (ap_uint<8>)(a - b) : (ap_uint<8>)(b - a);
}

ap_uint<8> clip_u8_from_int(int v) {
#pragma HLS INLINE
    if (v < 0) return 0;
    if (v > 255) return 255;
    return (ap_uint<8>)v;
}

YuvPixel rgb_to_yuv_bt601(ap_uint<8> r, ap_uint<8> g, ap_uint<8> b) {
#pragma HLS INLINE
    // 全范围 BT.601 近似整数实现
    int y_i = ((66 * (int)r + 129 * (int)g + 25 * (int)b + 128) >> 8) + 16;
    int u_i = ((-38 * (int)r - 74 * (int)g + 112 * (int)b + 128) >> 8) + 128;
    int v_i = ((112 * (int)r - 94 * (int)g - 18 * (int)b + 128) >> 8) + 128;

    YuvPixel yuv;
    yuv.y = clip_u8_from_int(y_i);
    yuv.u = clip_u8_from_int(u_i);
    yuv.v = clip_u8_from_int(v_i);
    return yuv;
}
