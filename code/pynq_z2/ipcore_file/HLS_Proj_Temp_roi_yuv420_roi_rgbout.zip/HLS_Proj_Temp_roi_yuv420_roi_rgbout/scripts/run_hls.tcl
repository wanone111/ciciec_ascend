# =============================================================================
# Purpose: Vitis HLS script for HDMI AXIS ROI/YUV processing IP
# Target: xc7z020clg400-1, 100MHz
# =============================================================================

exec sh -c "rm -f flex*.log"

set script_dir [file dirname [file normalize [info script]]]
set project_root [file normalize "$script_dir/.."]
set src_dir "$project_root/src"
set inc_dir "$project_root/include"
set tb_dir "$project_root/tb"

set build_root "$project_root/build"
set build_name "hls_roi_yuv420ish"
set build_output "$build_root/$build_name"
file mkdir $build_root
file mkdir $build_output

open_project -reset "$build_output/roi_stat_top_prj"
set_top roi_stat_top

set common_cflags "-I $inc_dir -I ./ -D__SDSVHLS__ -std=c++14"
add_files "$src_dir/top.cpp" -cflags "$common_cflags"
add_files "$src_dir/roi.cpp" -cflags "$common_cflags"
add_files -tb "$tb_dir/tb_top.cpp" -cflags "$common_cflags"

open_solution -reset solution1
set_part {xc7z020clg400-1}
create_clock -period 10
config_rtl -reset all -reset_level low

set run_csim 1
set run_cosim 1
set run_export 0

if {$run_csim} {
    csim_design
}

csynth_design

if {$run_cosim} {
    cosim_design
}

if {$run_export} {
    export_design -flow syn -rtl verilog
}

exit
