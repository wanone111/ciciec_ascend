#include <cstdint>
#include <iostream>

#include "top.h"

static axi_pixel_t make_pixel(uint8_t r, uint8_t g, uint8_t b, bool sof, bool last) {
    axi_pixel_t p;
    p.data.range(7, 0) = b;
    p.data.range(15, 8) = g;
    p.data.range(23, 16) = r;
    p.keep = -1;
    p.strb = -1;
    p.user = sof ? 1 : 0;
    p.last = last ? 1 : 0;
    p.id = 0;
    p.dest = 0;
    return p;
}

static void feed_frame(hls::stream<axi_pixel_t>& src, int rows, int cols, int bias) {
    for (int r = 0; r < rows; ++r) {
        for (int c = 0; c < cols; ++c) {
            uint8_t rr = (uint8_t)(20 + r * 5 + bias);
            uint8_t gg = (uint8_t)(40 + c * 7 + bias);
            uint8_t bb = (uint8_t)(60 + r * 3 + c * 2 + bias);
            src.write(make_pixel(rr, gg, bb, (r == 0 && c == 0), (c == cols - 1)));
        }
    }
}

int main() {
    const ap_uint<16> rows = 8;
    const ap_uint<16> cols = 8;
    const ap_uint<16> roi_x = 2;
    const ap_uint<16> roi_y = 2;
    const ap_uint<16> roi_w = 4;
    const ap_uint<16> roi_h = 4;

    hls::stream<axi_pixel_t> src0, dst0;
    hls::stream<axi_pixel_t> src1, dst1;

    ap_uint<32> y_mean = 0;
    ap_uint<32> motion_score = 0;
    ap_uint<32> u_mean_420 = 0;
    ap_uint<32> v_mean_420 = 0;

    feed_frame(src0, rows, cols, 0);
    roi_stat_top(src0, dst0, rows, cols, roi_x, roi_y, roi_w, roi_h,
                 1, 0, 1, y_mean, motion_score, u_mean_420, v_mean_420);

    std::cout << "[TB] frame0 y_mean=" << (unsigned)y_mean
              << " motion=" << (unsigned)motion_score
              << " u420=" << (unsigned)u_mean_420
              << " v420=" << (unsigned)v_mean_420 << std::endl;

    for (int i = 0; i < rows * cols; ++i) {
        (void)dst0.read();
    }

    feed_frame(src1, rows, cols, 12);
    roi_stat_top(src1, dst1, rows, cols, roi_x, roi_y, roi_w, roi_h,
                 1, 2, 0, y_mean, motion_score, u_mean_420, v_mean_420);

    int pixel_cnt = 0;
    int border_red_cnt = 0;
    int gray_roi_cnt = 0;
    for (int r = 0; r < rows; ++r) {
        for (int c = 0; c < cols; ++c) {
            axi_pixel_t p = dst1.read();
            ++pixel_cnt;
            uint8_t b = (uint8_t)p.data.range(7, 0);
            uint8_t g = (uint8_t)p.data.range(15, 8);
            uint8_t rr = (uint8_t)p.data.range(23, 16);

            bool in_roi = (r >= roi_y && r < roi_y + roi_h && c >= roi_x && c < roi_x + roi_w);
            bool on_border = in_roi &&
                             (r == roi_y || r == roi_y + roi_h - 1 || c == roi_x || c == roi_x + roi_w - 1);

            if (on_border && rr == 255 && g == 0 && b == 0) {
                ++border_red_cnt;
            }
            if (in_roi && !on_border && rr == g && g == b) {
                ++gray_roi_cnt;
            }
        }
    }

    std::cout << "[TB] frame1 y_mean=" << (unsigned)y_mean
              << " motion=" << (unsigned)motion_score
              << " u420=" << (unsigned)u_mean_420
              << " v420=" << (unsigned)v_mean_420
              << " pixels=" << pixel_cnt
              << " border_red=" << border_red_cnt
              << " gray_roi=" << gray_roi_cnt << std::endl;

    if (pixel_cnt != rows * cols) {
        std::cerr << "[TB][FAIL] output pixel count mismatch" << std::endl;
        return 1;
    }
    if (border_red_cnt == 0) {
        std::cerr << "[TB][FAIL] ROI border overlay missing" << std::endl;
        return 1;
    }
    if (gray_roi_cnt == 0) {
        std::cerr << "[TB][FAIL] ROI grayscale visualization missing" << std::endl;
        return 1;
    }
    if ((unsigned)y_mean == 0 || (unsigned)u_mean_420 == 0 || (unsigned)v_mean_420 == 0) {
        std::cerr << "[TB][FAIL] YUV statistics should not be zero" << std::endl;
        return 1;
    }

    std::cout << "[TB][PASS] roi_stat_top YUV420-style ROI behavior is correct" << std::endl;
    return 0;
}
